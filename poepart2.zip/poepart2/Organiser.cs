﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace poepart2
{
    
    
       
    
        public class Organiser
        {
            [Key]
            public int OrganiserId { get; set; }
            [Required, StringLength(100)]
            public string FullName { get; set; }
            [Required, EmailAddress, StringLength(100)]
            public string Email { get; set; }
            [Required, StringLength(20)]
            public string Phone { get; set; }
            [Required, StringLength(100)]
            public string Organisation { get; set; }
            [Required]
            public string PasswordHash { get; set; }
            public string? ProfilePicUrl { get; set; }
            public bool IsVerified { get; set; } = false;
            public DateTime CreatedAt { get; set; } = DateTime.Now;
            public DateTime UpdatedAt { get; set; } = DateTime.Now;

            public ICollection<Event> Events { get; set; } = new List<Event>();
        }

        public class Users
        {
            [Key]
            public int UserId { get; set; }
            [Required, StringLength(100)]
            public string FullName { get; set; }
            [Required, EmailAddress, StringLength(100)]
            public string Email { get; set; }
            [Required, StringLength(20)]
            public string Phone { get; set; }
            [Required]
            public DateTime DateOfBirth { get; set; }
            [Required, StringLength(13)]
            public string IdNumber { get; set; }
            [Required, StringLength(100)]
            public string EmergencyContact { get; set; }
            [Required, StringLength(20)]
            public string EmergencyPhone { get; set; }
            [Required]
            public string PasswordHash { get; set; }
            public string? ProfilePicUrl { get; set; }
            public string PreferredLanguage { get; set; } = "English";
            public bool IsActive { get; set; } = true;
            public DateTime CreatedAt { get; set; } = DateTime.Now;
            public DateTime UpdatedAt { get; set; } = DateTime.Now;

            public ICollection<ParticipantEntry> ParticipantEntries { get; set; } = new List<ParticipantEntry>();
        }

        public class Category
        {
            [Key]
            public int CategoryId { get; set; }
            [Required, StringLength(50)]
            public string CategoryName { get; set; }
            public string? CategoryDescription { get; set; }
            [Required]
            public decimal DistanceKm { get; set; }
            [Required]
            public decimal EntryFee { get; set; }
            public int? AgeMin { get; set; }
            public int? AgeMax { get; set; }
            public string GenderAllowed { get; set; } = "ALL"; // ALL, MALE, FEMALE
            public bool IsActive { get; set; } = true;
            public DateTime CreatedAt { get; set; } = DateTime.Now;
        }

        public class Event
        {
            [Key]
            public int EventId { get; set; }
            [Required]
            public int OrganiserId { get; set; }
            [Required, StringLength(150)]
            public string EventName { get; set; }
            [Required]
            public DateTime EventDate { get; set; }
            [Required]
            public TimeSpan EventTime { get; set; }
            [Required, StringLength(200)]
            public string Venue { get; set; }
            [Required, StringLength(100)]
            public string City { get; set; }
            [Required, StringLength(50)]
            public string Province { get; set; }
            public string Country { get; set; } = "South Africa";
            [Required]
            public int MaxParticipants { get; set; }
            public string EventStatus { get; set; } = "OPEN"; // DRAFT, OPEN, CLOSED, CANCELLED, COMPLETED
            public string? Description { get; set; }
            public string? RouteMapUrl { get; set; }
            public string? WeatherProviderRef { get; set; }
            public string? TermsAndConditions { get; set; }
            public string? BannerImageUrl { get; set; }
            public bool IsFeatured { get; set; } = false;
            public DateTime CreatedAt { get; set; } = DateTime.Now;
            public DateTime UpdatedAt { get; set; } = DateTime.Now;

            [ForeignKey("OrganiserId")]
            public Organiser Organiser { get; set; }
            public ICollection<EventCategory> EventCategories { get; set; } = new List<EventCategory>();
        }

        public class EventCategory
        {
            [Key]
            public int EventCategoryId { get; set; }
            [Required]
            public int EventId { get; set; }
            [Required]
            public int CategoryId { get; set; }
            [Required]
            public int Capacity { get; set; }
            public int EntriesCount { get; set; } = 0;
            [Required]
            public TimeSpan StartTime { get; set; }
            public TimeSpan? CutOffTime { get; set; }
            public decimal? PriceOverride { get; set; }
            public bool IsActive { get; set; } = true;
            public DateTime CreatedAt { get; set; } = DateTime.Now;
            public DateTime UpdatedAt { get; set; } = DateTime.Now;

            [ForeignKey("EventId")]
            public Event Event { get; set; }
            [ForeignKey("CategoryId")]
            public Category Category { get; set; }
            public ICollection<ParticipantEntry> ParticipantEntries { get; set; } = new List<ParticipantEntry>();
        }

        public class ParticipantEntry
        {
            [Key]
            public int EntryId { get; set; }
            [Required]
            public int EventCategoryId { get; set; }
            [Required]
            public int UserId { get; set; }
            public DateTime EntryDate { get; set; } = DateTime.Now;
            [Required]
            public int RaceNumber { get; set; }
            public string? TShirtSize { get; set; } // XS, S, M, L, XL, XXL, XXXL
            [Required, StringLength(100)]
            public string EmergencyContact { get; set; }
            [Required, StringLength(20)]
            public string EmergencyPhone { get; set; }
            public string PaymentStatus { get; set; } = "PENDING"; // PENDING, PAID, FAILED, REFUNDED
            public string? PaymentReference { get; set; }
            public string EntryStatus { get; set; } = "CONFIRMED"; // PENDING, CONFIRMED, WAITLIST, CANCELLED, WITHDRAWN
            public int? ResultTimeSeconds { get; set; }
            public int? ResultPosition { get; set; }
            public string ResultStatus { get; set; } = "DNS"; // DNS, DNF, FINISHED
            public string? ResultCertificateUrl { get; set; }
            public TimeSpan? WaveStartTime { get; set; }
            public string? Notes { get; set; }
            public DateTime CreatedAt { get; set; } = DateTime.Now;
            public DateTime UpdatedAt { get; set; } = DateTime.Now;

            [ForeignKey("EventCategoryId")]
            public EventCategory EventCategory { get; set; }
            [ForeignKey("UserId")]
            public Users User { get; set; }
        }
    }

