﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using poepart2.Controllers.RaceDayAPI.Controllers;

namespace poepart2.Controllers
{
   
      
        [Route("api/[controller]")]
        [ApiController]
        public class EventsController : ControllerBase
        {
            private readonly RaceDayDbContext _context;

        public object EntityState { get; private set; }

        public EventsController(RaceDayDbContext context)
            {
                _context = context;
            }

            // GET: api/events
            [HttpGet]
            public async Task<ActionResult<IEnumerable<Event>>> GetEvents()
            {
                return await _context.vents.Include(e => e.Organiser).ToListAsync();
            }

            // GET: api/events/5
            [HttpGet("{id}")]
            public async Task<ActionResult<Event>> GetEvent(int id)
            {
                var @event = await _context.events
                    .Include(e => e.Organiser)
                    .Include(e => e.EventCategories)
                    .ThenInclude(ec => ec.Category)
                    .FirstOrDefaultAsync(e => e.EventId == id);

                if (@event == null) return NotFound();
                return @event;
            }

            // POST: api/events (Organiser only)
            [HttpPost]
            [Authorize(Roles = "Organiser")]
            public async Task<ActionResult<Event>> CreateEvent(Event @event)
            {
                _context.Events.Add(@event);
                await _context.SaveChangesAsync();
                return CreatedAtAction(nameof(GetEvent), new { id = @event.EventId }, @event);
            }

            // PUT: api/events/5 (Organiser only)
            [HttpPut("{id}")]
            [Authorize(Roles = "Organiser")]
            public async Task<IActionResult> UpdateEvent(int id, Event @event)
            {
                if (id != @event.EventId) return BadRequest();

            _context.Entry(@event).State = EntityState.Modified;
            try
                {
                    await _context.SaveChangesAsync();
                }
            catch (DbUpdateConcurrencyException)
                {
                    if (!EventExists(id)) return NotFound();
                    else throw;
                }
                return NoContent();
            }

            // DELETE: api/events/5 (Organiser only)
            [HttpDelete("{id}")]
            [Authorize(Roles = "Organiser")]
            public async Task<IActionResult> DeleteEvent(int id)
            {
                var @event = await _context.events.FindAsync(id);
                if (@event == null) return NotFound();

                _context.events.Remove(@event);
                await _context.SaveChangesAsync();
                return NoContent();
            }

            private bool EventExists(int id)
            {
                return _context.events.Any(e => e.EventId == id);
            }
        }
    }


