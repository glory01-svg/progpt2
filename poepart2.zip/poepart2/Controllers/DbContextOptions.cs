﻿namespace poepart2.Controllers.RaceDayAPI.Controllers
{
    public class DbContextOptions<T>
    {
    }
}