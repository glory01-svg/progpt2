﻿using poepart2.models;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection.Emit;

namespace poepart2.Controllers.RaceDayAPI.Controllers
{
    public class RaceDayDbContext
    {
        internal object events;

        public RaceDayDbContext(DbContextOptions<RaceDayDbContext> options) : base(options)
        {
        }

            protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
            object value = base.OnModelCreating(modelBuilder);

                
                modelBuilder.Entity<models.Users>()
                    .HasIndex((object u) => u.Email)
                    .IsUnique();

                modelBuilder.Entity<Organiser>()
                    .HasIndex(o => o.Email)
                    .IsUnique();

                
                modelBuilder.Entity<Race>()
                    .HasOne(r => r.Organiser)
                    .WithMany()
                    .HasForeignKey(r => r.OrganiserId)
                    .OnDelete(DeleteBehavior.Cascade);
            }
        }
    }

    




