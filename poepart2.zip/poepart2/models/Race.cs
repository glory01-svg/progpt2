﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace poepart2.models
{
    public class Race
   
        {
            [Key]
            public int RaceId { get; set; }

            [Required]
            public string RaceName { get; set; } = string.Empty;

            public string Category { get; set; } = string.Empty; 

            public double DistanceKm { get; set; }

            public DateTime StartTime { get; set; }

            public string StartLocation { get; set; } = string.Empty;

            public string EndLocation { get; set; } = string.Empty;

            public int MaxParticipants { get; set; }

           
            public int EventId { get; set; }

            [ForeignKey("EventId")]
            public Event? Event { get; set; }

           
            public int OrganiserId { get; set; }

            [ForeignKey("OrganiserId")]
            public Organiser? Organiser { get; set; }

            public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

            [Timestamp]
            public byte[]? RowVersion { get; set; }
        }
    }


