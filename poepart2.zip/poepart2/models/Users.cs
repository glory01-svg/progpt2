﻿using System.ComponentModel.DataAnnotations;

namespace poepart2.models
{
   
    
        public class Users
        {
            [Key]
            public int UserId { get; set; }

            [Required]
            public string FullName { get; set; } = string.Empty;

            [Required]
            [EmailAddress]
            public string Email { get; set; } = string.Empty;

            [Required]
            public string PasswordHash { get; set; } = string.Empty;

            public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

            [Timestamp]
            public byte[]? RowVersion { get; set; }
        }
    }


