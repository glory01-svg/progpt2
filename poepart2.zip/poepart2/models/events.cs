﻿using poepart2.Controllers.RaceDayAPI.Controllers;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace poepart2.models
{
    public class events
    {
            [Key]
            public int EventId { get; set; }

            [Required]
            public string EventName { get; set; } = string.Empty;

            public string Description { get; set; } = string.Empty;

            [Required]
            public DateTime EventDate { get; set; }

            public string Location { get; set; } = string.Empty;

            public double DistanceKm { get; set; }

            public int MaxParticipants { get; set; }

            public decimal EntryFee { get; set; }

            // Foreign Key to Organiser
            public int OrganiserId { get; set; }

            [ForeignKey("OrganiserId")]
            public Organiser? Organiser { get; set; }

           
            public int? RaceId { get; set; }

            [ForeignKey("RaceId")]
            public Race? Race { get; set; }

            public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

            [Timestamp]
            public byte[]? RowVersion { get; set; }
        }
    }


