﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace RaceDay.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResultsController : Controller
    {
            private readonly RaceDayDbContext _context;
            public ResultsController(RaceDayDbContext context) => _context = context;

            [HttpPost("capture")]
            [Authorize(Roles = "Organiser")]
            public async Task<IActionResult> CaptureResult([FromBody] CaptureResultDto request)
            {
                var enrollment = await _context.Enrollment.FindAsync(request.EntryId);
                if (enrollment == null) return NotFound("Enrollment not found");

                enrollment.ResultTimeSeconds = request.TimeSeconds;
                enrollment.ResultPosition = request.Position;
                enrollment.ResultStatus = "FINISHED";

                await _context.SaveChangesAsync();
                return Ok(new { message = "Result captured successfully" });
            }

            [HttpGet("my-results")]
            [Authorize(Roles = "Participant")]
            public async Task<IActionResult> GetMyResults()
            {
                var userId = int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value);
                var results = await _context.Enrollment
                    .Include(e => e.EventCategory).ThenInclude(ec => ec.Event)
                    .Where(e => e.UserId == userId && e.ResultStatus == "FINISHED")
                    .Select(e => new
                    {
                        EventName = e.EventCategory.Event.EventName,
                        Category = e.EventCategory.Category.CategoryName,
                        TimeFormatted = TimeSpan.FromSeconds(e.ResultTimeSeconds ?? 0).ToString(@"hh\:mm\:ss"),
                        Position = e.ResultPosition,
                        Status = e.ResultStatus
                    })
                    .ToListAsync();

                return Ok(results);
            }
        }

        public class CaptureResultDto
        {
            public int EntryId { get; set; }
            public int TimeSeconds { get; set; }
            public int Position { get; set; }
        }
    }
