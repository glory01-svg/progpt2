﻿using RaceDay.models;
using System.Reflection.Emit;
using static RaceDay.Data.RaceDayDbContext;

namespace RaceDay.Controllers
{
    public class RaceDayDbContext
    {
      
            public RaceDayDbContext(DbContextOptions<RaceDayDbContext> options) 
            {
            }

           
            public DbSet<organiser> Organisers { get; set; }
            public DbSet<AppUser> Users { get; set; }
            public DbSet<Event> Events { get; set; }
            public DbSet<Category> Categories { get; set; }
            public DbSet<EventCategory> EventCategories { get; set; }
            public DbSet<Enrollment> Enrollment { get; set; }
            

            
            protected override void OnModelCreating(Modelbuilder modelBuilder)
            {
            object value = base.OnModelCreating(modelBuilder);

                modelBuilder.Entity<AppUser>().ToTable("User");
                
                modelBuilder.Entity<Enrollment>().ToTable("ParticipantEntry");

                
                modelBuilder.Entity<organiser>()
                    .HasIndex(o => o.Email)
                    .IsUnique();

                modelBuilder.Entity<AppUser>()
                    .HasIndex(u => u.Email)
                    .IsUnique();

                modelBuilder.Entity<AppUser>()
                    .HasIndex(u => u.IdNumber)
                    .IsUnique();

                modelBuilder.Entity<Enrollment>()
                    .HasIndex(e => e.RaceNumber)
                    .IsUnique();

                
                modelBuilder.Entity<EventCategory>()
                    .HasIndex(ec => new { ec.EventId, ec.CategoryId })
                    .IsUnique()
                    .HasDatabaseName("UQ_EventCategory");

                modelBuilder.Entity<Enrollment>()
                    .HasIndex(e => new { e.UserId, e.EventCategoryId })
                    .IsUnique()
                    .HasDatabaseName("UQ_UserEventCategory");

               
                modelBuilder.Entity<Event>()
                    .HasOne(e => e.Organiser)
                    .WithMany(o => o.Events)
                    .HasForeignKey(e => e.OrganiserId);
                    

                modelBuilder.Entity<EventCategory>()
                    .HasOne(ec => ec.Event)
                    .WithMany(e => e.EventCategories)
                    .HasForeignKey(ec => ec.EventId);
                    

                modelBuilder.Entity<EventCategory>()
                    .HasOne(ec => ec.Category)
                    .WithMany(c => c.EventCategories)
                    .HasForeignKey(ec => ec.CategoryId);
                    

                modelBuilder.Entity<Enrollment>()
                    .HasOne(e => e.EventCategory)
                    .WithMany(ec => ec.Enrollments)
                    .HasForeignKey(e => e.EventCategoryId);


                modelBuilder.Entity<Enrollment>()
                    .HasOne(e => e.User)
                    .WithMany(u => u.Enrollments)
                    .HasForeignKey(e => e.UserId);
                    
            }

        internal object Entry(Event eventObj)
        {
            throw new NotImplementedException();
        }

        internal object Entry(Category category)
        {
            throw new NotImplementedException();
        }

        internal async Task SaveChangesAsync()
        {
            throw new NotImplementedException();
        }

        public class DbSet<T>
        {
        }
    }
    }

