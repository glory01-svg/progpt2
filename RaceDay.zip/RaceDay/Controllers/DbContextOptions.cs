﻿namespace RaceDay.Controllers
{
    public class DbContextOptions<T>
    {
    }
}