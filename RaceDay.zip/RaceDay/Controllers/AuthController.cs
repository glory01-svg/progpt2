﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using RaceDay.models;
using System.Security.Claims;

namespace RaceDay.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : Controller
    {
            private readonly RaceDayDbContext _context;
            public AuthController(RaceDayDbContext context) => _context = context;

            [HttpPost("register")]
            public async Task<IActionResult> Register([FromBody] RegisterDto request)
            {
                

                if (request.Role == "Organiser")
                {
                    var org = new organiser
                    {
                        FullName = request.FullName,
                        Email = request.Email,
                        Phone = request.Phone,
                        Organisation = request.Organisation,
                        PasswordHash = request.Password 
                    };
                    _context.Organisers.Add(org);
                    await _context.SaveChangesAsync();
                    return Ok(new { message = "Organiser registered successfully", organiser_id = org.OrganiserId });
                }
                else if (request.Role == "Participant")
                {
                    var user = new AppUser
                    {
                        FullName = request.FullName,
                        Email = request.Email,
                        Phone = request.Phone,
                        DateOfBirth = request.DateOfBirth,
                        IdNumber = request.IdNumber,
                        EmergencyContact = request.EmergencyContact,
                        EmergencyPhone = request.EmergencyPhone,
                        PasswordHash = request.Password 
                    };
                    _context.Users.Add(user);
                    await _context.SaveChangesAsync();
                    return Ok(new { message = "User registered successfully", user_id = user.UserId });
                }
                return BadRequest("Invalid role specified.");
            }

            [HttpPost("login")]
            public async Task<IActionResult> Login([FromBody] LoginDto request)
            {
                
                int userId = 0;
                string role = "";
                string storedHash = "";

                if (request.Role == "Organiser")
                {
                    var org = await _context.Organisers.FirstOrDefaultAsync(o => o.Email == request.Email);
                    if (org != null) { userId = org.OrganiserId; role = "Organiser"; storedHash = org.PasswordHash; }
                }
                else
                {
                    var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == request.Email);
                    if (user != null) { userId = user.UserId; role = "Participant"; storedHash = user.PasswordHash; }
                }

                
                if (userId == 0 || storedHash != request.Password)
                    return Unauthorized("Invalid credentials.");

                
                var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
                new Claim(ClaimTypes.Email, request.Email),
                new Claim(ClaimTypes.Role, role)
            };

                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity));

                return Ok(new { message = "Logged in successfully", userId, role });
            }

            [HttpPost("logout")]
            public async Task<IActionResult> Logout()
            {
                await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                return Ok(new { message = "Logged out successfully" });
            }
        }

        public class RegisterDto
        {
            public string FullName { get; set; }
            public string Email { get; set; }
            public string Phone { get; set; }
            public string Password { get; set; }
            public string Role { get; set; } 

            
            public string? Organisation { get; set; }

            
            public DateTime DateOfBirth { get; set; }
            public string? IdNumber { get; set; }
            public string? EmergencyContact { get; set; }
            public string? EmergencyPhone { get; set; }
        }

        public class LoginDto
        {
            public string Email { get; set; }
            public string Password { get; set; }
            public string Role { get; set; }
        }
    }