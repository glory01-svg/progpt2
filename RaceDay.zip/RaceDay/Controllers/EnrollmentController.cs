﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.models;

namespace RaceDay.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnrollmentController : Controller
    {
      
            private readonly RaceDayDbContext _context;
            public EnrollmentController(RaceDayDbContext context) => _context = context;

            [HttpPost]
            [Authorize(Roles = "Participant")]
            public async Task<IActionResult> Enroll([FromBody] Enrollment enrollment)
            {
                var userId = int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value);
                enrollment.UserId = userId;
                enrollment.EntryDate = DateTime.Now;

                
                var eventCategory = await _context.EventCategories.FindAsync(Enrollment.EventCategoryId);
                if (eventCategory == null) return NotFound("Category not found");
                if (eventCategory.EntriesCount >= eventCategory.Capacity) return BadRequest("Category is full");

            
                eventCategory.EntriesCount++;
                await _context.SaveChangesAsync();

                return Ok(new { message = "Enrolled successfully", entryId = enrollment.EntryId });
            }

            [HttpGet("event/{eventId}")]
            [Authorize(Roles = "Organiser")]
            public async Task<IActionResult> GetEnrollmentsForEvent(int eventId)
            {
                var enrollments = await _context.Enrollment
                    .(e => e.AppUser)
                    .Include(e => e.EventCategory)
                    .Where(e => e.EventCategory.EventId == eventId)
                    .ToListAsync();
                return Ok(enrollments);
            }
        }
    }
