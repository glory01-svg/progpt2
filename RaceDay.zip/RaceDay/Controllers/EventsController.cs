﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.models;

namespace RaceDay.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : Controller
    {
      
        
            private readonly RaceDayDbContext _context;
            public EventsController(RaceDayDbContext context) => _context = context;

            [HttpGet]
            public async Task<IActionResult> GetEvents()
            {
                var events = await _context.Events.Include(e => e.EventCategories).ThenInclude(ec => ec.Category).ToListAsync();
                return Ok(events);
            }

            [HttpGet("{id}")]
            public async Task<IActionResult> GetEvent(int id)
            {
                var eventObj = await _context.Events.Include(e => e.EventCategories).ThenInclude(ec => ec.Category).FirstOrDefaultAsync(e => e.EventId == id);
                if (eventObj == null) return NotFound();
                return Ok(eventObj);
            }

            [HttpPost]
            [Authorize(Roles = "Organiser")]
            public async Task<IActionResult> CreateEvent([FromBody] Event eventObj)
            {
                
                var organiserId = int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value);
                eventObj.OrganiserId = organiserId;

                _context.Events.Add(eventObj);
                await _context.SaveChangesAsync();
                return CreatedAtAction(nameof(GetEvent), new { id = eventObj.EventId }, eventObj);
            }

            [HttpPut("{id}")]
            [Authorize(Roles = "Organiser")]
            public async Task<IActionResult> UpdateEvent(int id, [FromBody] Event eventObj)
            {
                if (id != eventObj.EventId) return BadRequest();
                _context.Entry(eventObj).State = EntityState.Modified;
                await _context.SaveChangesAsync();
                return NoContent();
            }

            [HttpDelete("{id}")]
            [Authorize(Roles = "Organiser")]
            public async Task<IActionResult> DeleteEvent(int id)
            {
            var eventObj = await _context.Events.FindAsync(id);
                if (eventObj == null) return NotFound();

                _context.Events.Remove(eventObj);
                await _context.SaveChangesAsync();
                return NoContent();
            }
        }
    }
