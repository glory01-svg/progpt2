﻿using System.ComponentModel.DataAnnotations;

namespace RaceDay.models
{
    public class organiser
    {
       
            [Key]
            public int OrganiserId { get; set; }
            [Required]
            [StringLength(100)]
            public string FullName { get; set; }
            [Required]
            [EmailAddress]
            public string Email { get; set; }
            [Required]
            public string Phone { get; set; }
            [Required]
            public string Organisation { get; set; }
            [Required]
            public string PasswordHash { get; set; }
            public string? ProfilePicUrl { get; set; }
            public bool IsVerified { get; set; } = false;
            public DateTime CreatedAt { get; set; } = DateTime.Now;
            public DateTime UpdatedAt { get; set; } = DateTime.Now;

            public ICollection<Event> Events { get; set; }
        }
    }


