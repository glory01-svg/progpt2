﻿using System.ComponentModel.DataAnnotations;

namespace RaceDay.models
{
    public class AppUser
    {
       
            [Key]
            public int UserId { get; set; }
            [Required]
            public string FullName { get; set; }
            [Required]
            [EmailAddress]
            public string Email { get; set; }
            [Required]
            public string Phone { get; set; }
            [Required]
            public DateTime DateOfBirth { get; set; }
            [Required]
            public string IdNumber { get; set; }
            [Required]
            public string EmergencyContact { get; set; }
            [Required]
            public string EmergencyPhone { get; set; }
            [Required]
            public string PasswordHash { get; set; }
            public string? ProfilePicUrl { get; set; }
            public string PreferredLanguage { get; set; } = "English";
            public bool IsActive { get; set; } = true;
            public DateTime CreatedAt { get; set; } = DateTime.Now;
            public DateTime UpdatedAt { get; set; } = DateTime.Now;

            public ICollection<Enrollment> Enrollments { get; set; }
        }
    }


