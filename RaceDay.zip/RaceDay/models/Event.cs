﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaceDay.models
{
    public class Event
    {
        
            [Key]
            public int EventId { get; set; }
            [Required]
            public int OrganiserId { get; set; }
            [ForeignKey("OrganiserId")]
            public organiser Organiser { get; set; }

            [Required]
            public string EventName { get; set; }
            [Required]
            public DateTime EventDate { get; set; }
            [Required]
            public TimeSpan EventTime { get; set; }
            [Required]
            public string Venue { get; set; }
            [Required]
            public string City { get; set; }
            [Required]
            public string Province { get; set; }
            public string Country { get; set; } = "South Africa";
            [Required]
            public int MaxParticipants { get; set; }
            public string EventStatus { get; set; } = "OPEN"; // DRAFT, OPEN, CLOSED, CANCELLED, COMPLETED
            public string? Description { get; set; }
            public string? RouteMapUrl { get; set; }
            public string? WeatherProviderRef { get; set; }
            public string? TermsAndConditions { get; set; }
            public string? BannerImageUrl { get; set; }
            public bool IsFeatured { get; set; } = false;
            public DateTime CreatedAt { get; set; } = DateTime.Now;
            public DateTime UpdatedAt { get; set; } = DateTime.Now;

           
        }
    }


