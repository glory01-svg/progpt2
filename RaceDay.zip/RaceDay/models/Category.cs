﻿using System.ComponentModel.DataAnnotations;

namespace RaceDay.models
{
    public class Category
    {
      
        
            [Key]
            public int CategoryId { get; set; }
            [Required]
            public string CategoryName { get; set; }
            public string? CategoryDescription { get; set; }
            [Required]
            public decimal DistanceKm { get; set; }
            [Required]
            public decimal EntryFee { get; set; }
            public int? AgeMin { get; set; }
            public int? AgeMax { get; set; }
            public string GenderAllowed { get; set; } = "ALL"; // ALL, MALE, FEMALE
            public bool IsActive { get; set; } = true;
            public DateTime CreatedAt { get; set; } = DateTime.Now;

            public ICollection<EventCategory> EventCategories { get; set; }
        }
    }


