﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaceDay.models
{
    public class Enrollment
    {
        
        
            [Key]
            public int EntryId { get; set; }
            [Required]
            public int EventCategoryId { get; set; }
            [ForeignKey("EventCategoryId")]
            public EventCategory EventCategory { get; set; }

            [Required]
            public int UserId { get; set; }
            [ForeignKey("UserId")]
            public AppUser User { get; set; }

            public DateTime EntryDate { get; set; } = DateTime.Now;
            [Required]
            public int RaceNumber { get; set; }
            public string? TShirtSize { get; set; }
            public string? EmergencyContact { get; set; }
            public string? EmergencyPhone { get; set; }
            public string PaymentStatus { get; set; } = "PENDING"; // PENDING, PAID, FAILED, REFUNDED
            public string? PaymentReference { get; set; }
            public string EntryStatus { get; set; } = "CONFIRMED"; // PENDING, CONFIRMED, WAITLIST, CANCELLED, WITHDRAWN
            public int? ResultTimeSeconds { get; set; }
            public int? ResultPosition { get; set; }
            public string ResultStatus { get; set; } = "DNS"; // DNS, DNF, FINISHED
            public string? ResultCertificateUrl { get; set; }
            public TimeSpan? WaveStartTime { get; set; }
            public string? Notes { get; set; }
            public DateTime CreatedAt { get; set; } = DateTime.Now;
            public DateTime UpdatedAt { get; set; } = DateTime.Now;
        }

    public class EventCategory
    {
    }
}


