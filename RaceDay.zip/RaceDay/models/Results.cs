﻿namespace RaceDay.models
{
    public class Results
    {
       
            public int ResultId { get; set; }
            public int EntryId { get; set; }
            public int UserId { get; set; }
            public int EventId { get; set; }
            public TimeSpan FinishTime { get; set; }
            public int Position { get; set; }
            public string Status { get; set; }
        }
    }


